//Osnovne JavaScript vežbe – VARIJABLE
let ime = 'Ana';
console.log(ime);
let godine = 20;
console.log(godine);
let jeStudent = true;
console.log(jeStudent);
let grad = 'Beograd';
console.log('Zivim u gradu'+' '+grad);

//Brojevi i math operatori
let a = 10;
let b = 5;
console.log('zbir:', a+b);
console.log('razlika:', a-b);
console.log('prozivod:', a*b);
console.log('kolicnik:', a/b);
console.log('ostatak:', a%b);
a++;
console.log('nova vrednost', a);
b--;
console.log('nova vrednost', b);
let x = 3;
let y = 4;
console.log('(x + y) * 2 =', (x+y)*2);

//String vežbe + replace()
let string1 = 'ucim programiranje';
console.log(string1);
string1 = string1.replace('ucim programiranje', 'ucim kodiranje');
console.log(string1);
let  string2 = 'danas je lep dan';
console.log(string2);
string2 = string2.replace('lep', 'suncan');
console.log(string2);
let string3 = 'Moje ime je Ana';
console.log(string3);
string3 = string3.replace('Ana', 'Marko');
console.log(string3);

//Kombinovane vežbe
let poruka = 'Ucim osnove JavaScript';
console.log(poruka);
poruka = poruka.replace('osnove', 'napredne');
console.log(poruka);
let broj = 10;
console.log('vrednost broja je'+' '+ broj);
console.log(`Imam ${godine} godina`);
let jeOnline = false;
console.log(jeOnline);
let c = 7;
let d = 2;
console.log('Zbir c i d varijabli je', c+d);
let text = 'JavaScript je zabavan';
console.log(text);
text = text.replace('zabavan', 'koristan');
console.log(text);
let rezultat = c*d;
console.log('rezultat od c i d je ', rezultat);
console.log('rezultat je ' + rezultat);
//zdravo Tomo xD


